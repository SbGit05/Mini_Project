a = 5
b = 10

sum = a + b
print("The addition of {0} and {1} is {2}".format(a,b,sum))