<?php 
  session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: Home Page.html");
  }
?>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="apple-touch-icon" href="https://billzer.com/touch-icon-iphone.png" />
<link rel="apple-touch-icon" sizes="76x76" href="https://billzer.com/touch-icon-ipad.png" />
<link rel="apple-touch-icon" sizes="120x120" href="https://billzer.com/touch-icon-iphone-retina.png" />
<link rel="apple-touch-icon" sizes="152x152" href="https://billzer.com/touch-icon-ipad-retina.png" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<link rel="alternate" hreflang="x-default" href="https://billzer.com/" />
<link rel="alternate" hreflang="en" href="https://billzer.com/en/" />
<link rel="alternate" hreflang="de" href="https://billzer.com/de/" />
<link rel="alternate" hreflang="it" href="https://billzer.com/it/" />
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Rancho">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Rancho&effect=neon|outline|emboss|shadow-multiple">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Redressed">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Redressed&effect=neon|outline|emboss|shadow-multiple">
<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<meta property="og:type" content="website"/>
<meta property="og:url" content="https://billzer.com/"/>
<meta property="og:title" content="billzer.com - Split bills for shared group expenses."/>
<meta property="og:image" content="https://billzer.com/logosuper.png"/>
<meta property="og:description" content="We tell you who owes whom and how to settle debts in groups with shared costs after holidays, partys, in shared apartments and so much more." />
<meta property="og:locale" content="en_US" />
<meta property="og:locale:alternate" content="de_DE" /><meta property="og:locale:alternate" content="it_IT" /> 
<meta property="og:site_name" content="billzer" />
<meta property="fb:app_id" content="1546057258948948" />

<meta name="description" content="We tell you who owes whom and how to settle debts in groups with shared costs after holidays, partys, in shared apartments and so much more." />
<meta name="keywords" content="split the bills, how to split costs in group, how to split expenses in group, road trips, share bills, bills calculator, expenses calculator, split expenses caluclator, shared bills, bills app, shared expenses app, bills paid, splitting expenses, app for splitting bills, split mobile, split cost app, split costs calculator, trip, settle debts, shared expenses, shared costs, Group spendings, Calculate transactions, Who owes whom how much, Who pay whom how much, IOU, pay back debts, share bills, Balance, Split costs with friends, calculator, uneven splits" />
<meta name="robots" content="index,follow" />

<title>Equipay - Split bills for shared group expenses.</title>
<script src="https://the.gatekeeperconsent.com/cmp.min.js" data-cfasync="false"></script>
<script async src="//www.ezojs.com/ezoic/sa.min.js"></script>
<script>
    window.ezstandalone = window.ezstandalone || {};
    ezstandalone.cmd = ezstandalone.cmd || [];
    ezstandalone.cmd.push(function() {
        ezstandalone.define(102,103,104,110,111);
        ezstandalone.enable();
        ezstandalone.display();
    });
</script>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-3739675874269991" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-1.11.0.min.js"></script>
<script src="https://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
<script type="text/javascript">
function change(what){
$('#scroll').fadeOut();
var current = document.getElementById("count").value;
var current = parseInt(current);
if(what == "u"){
	if (current > 1 && current < 40) {
	var neu = current+1;
	document.getElementById("count").value= neu;
	}
	}
else {
	if (current > 2 && current < 41) {
	var neu = (current)-1;
	document.getElementById("count").value= neu;
	}
	}
}
 $(document).on('focus', '#text', function() {
	$('#scroll').fadeOut();
 });
$(window).scroll(function() {

    if ($(this).scrollTop()>0)
     {
        $('#scroll').fadeOut();
     }
     
});
$("document").ready(function(){

	 $(document).on('click', '.cookieclose', function() {
	$('#cookiestart').remove();
        });

$("select").selectpicker({style: 'btn-hg btn-info', menuStyle: 'dropdown-inverse'});

$.fn.pressEnter = function(func) {
    this.bind('keypress', function(e) {
        if(e.keyCode === 13) {
            func.apply(this, [e]);
        }
    });
    return this;
};

$('input[type="text"]').pressEnter(function(e) {
    e.preventDefault();
    $('.action').submit();
});


});
</script>


    <!-- Loading Bootstrap -->
    <link href="https://billzer.com/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Loading Flat UI -->
    <link href="https://billzer.com/css/flat-ui.css" rel="stylesheet">

    

    <!-- HTML5 shim, for IE6-8 support of HTML5 elements. All other JS at the end of file. -->
    <!--[if lt IE 9]>
      <script src="https://billzer.com/js/html5shiv.js"></script>
      <script src="https://billzer.com/js/respond.min.js"></script>
    <![endif]--><link href="https://billzer.com/style.css?v=1527233455" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="https://billzer.com/css/customfont.css">
<link rel="shortcut icon" href="https://i.ibb.co/mRsDprM/Logo.png" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
<link rel="stylesheet" href="https://billzer.com/css/main.css" />
</head>
<body style="
background-image:url(https://cdn.pixabay.com/photo/2020/05/23/12/33/flowers-5209386_1280.jpg);
background-repeat: no-repeat;
background-position: center;
background-size: cover;">
<script>
   var gaProperty = 'UA-55249825-1'; 
   var disableStr = 'ga-disable-' + gaProperty; 
   if (document.cookie.indexOf(disableStr + '=true') > -1) { 
        window[disableStr] = true;
    } 
    function gaOptout() { 
        document.cookie = disableStr + '=true; expires=Thu, 31 Dec 2099 23:59:59 UTC; path=/'; 
        window[disableStr] = true; 
        alert('Das Tracking ist jetzt deaktiviert'); 
   } 
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-55249825-1', 'auto');
  ga('set', 'anonymizeIp', true);
  ga('send', 'pageview');

</script><div id="wrap">
<div class="container" id="container">
<div class="container1" style="display: flex; justify-content: center;">
<img src="https://i.ibb.co/mRsDprM/Logo.png" alt="Logo" >    
</div>
<div id="claim"><h1 class = "font-effect-emboss" style = "font-family: Rancho; color: rgb(45,132,219); font-size: 55px; font weight: bold">Split bills for shared group expenses. <br />We tell you who owes whom and how to settle debts in groups.</h1></div>
<br />
<div class="mycont" style = "display: flex; justify-content: center;">
<?php  if (isset($_SESSION['username'])) : ?>
	<h4 style = "font-family: Redressed; font-size: 50px">Welcome <strong><?php echo $_SESSION['username']; ?></strong></h4>
<?php endif ?>
</div>
<!-- Ezoic - main_top_of_page - top_of_page -->
<div id="ezoic-pub-ad-placeholder-110"> </div>
<!-- End Ezoic - main_top_of_page - top_of_page -->
<div id="startform">
	<form class="action" name="action" action="https://billzer.com/go.php" method="post">
		<div id="tops"><a href="https://billzer.com/my/example/"><div class="topcall"><i class='bx bx-question-mark'></i> Show example</div></a>
		 or		</div>
		<a name="top"></a><a href="#top"><div class="topcallstart"><i class='bx bxs-file-plus'></i> Start new calculation</div></a>
		<div id="gobox">
			How many people are in your group?<br />
			<div id="countw">
				<div id="down">
				<input value="-" type="button" onclick="change('d')" class="btn btn-hg btn-info"/>
				</div>
				<div id="countw2">
					<div class="form-group">
						<div class="input-group">
						<span class="input-group-addon"><i class='bx bxs-group'></i></span> <input type="number" min="2" max="40" step="1" name="p" value="3" id="count" class="form-control input-hg">
				</div></div></div>
				<div id="up">
				<input value="+" type="button" onclick="change('u')" class="btn btn-hg btn-info"/>
				</div>
			<span class="hint" style="font-size: medium;">People can be excluded from single expenses later</span>
			</div>
			<input type="hidden" value="none" name="o" />
			<br />
			Give it a name!			<br />
			<input maxlength="40" type="text" id="text" name="name" placeholder="e.g. Roadtrip" class="form-control"/>
			<br />
			
			<input value="Go!" id="go" class="btn btn-hg btn-success" type="submit">
			</div></form>
</div><!-- /#startform -->
<div id="facebookwrap"></div>
<br /><br />
<!-- Ezoic - main_under first paragraph - under_first_paragraph -->
<div id="ezoic-pub-ad-placeholder-102"> </div>
<!-- End Ezoic - main_under first paragraph - under_first_paragraph -->
<div class="breaker"></div>
<div id="how"><h2 style="font-size: 40px; font-weight: bold;">What you get</h2>
<div id="howpic">
	<img src="https://www.clio.com/wp-content/uploads/2021/11/Legal-payment-processing-software_featured-image-750x422.png" height="365px" width="510px">
</div>
<div id="howtext" style="color:black;"><p style="font-size: large;">Very often on holiday, at partys, for presents or in free-time everyone pays something for a group of people.
Calculating the payments afterwards to even out the group can be a daunting and complicated task
(even with a calculator) - especially when
some expenses are not shared with all group members.
<br /><br />

EquiPay.com helps you with that: After you entered everyone's name and the spendings she or he had for the group, the EquiPay calculator tells you who owes whom how much and how to settle debts in the group.
<br /><br />
It is also possible for expenses not be shared with the whole group and only among specific people.</p>
</div>
</div>
<br /><br />
<!-- Ezoic - main_under_second_paragraph - under_second_paragraph -->
<div id="ezoic-pub-ad-placeholder-103"> </div>
<!-- End Ezoic - main_under_second_paragraph - under_second_paragraph -->
<div class="breaker"></div>
<div id="threer">
	<h2 style="font-size: 40px;">Good to know...</h2>
	<div class="col">
		<div class="colimage"><img src="https://billzer.com/images/icons/svg/gift-box.svg" width="100px" height="100px" alt="a gift box"/></div>
		<div class="coltext" style="color: black;">It's free. <br /><br />It's easy.</div>
	</div>
	<div class="col">
		<div class="colimage"><img src="https://billzer.com/images/icons/svg/clipboard.svg" width="100px" height="100px" alt="a clipboard" /></div>
		<div class="coltext" style="color: black;">No Hardwork. <br /><br /> No download.</div>
	</div>
	<div class="col">
		<div class="colimage"><img src="https://billzer.com/images/icons/svg/pencils.svg" width="100px" height="100px" alt="pencils" /></div>
		<div class="coltext" style="color: black;">Share the result. <br /><br /> Edit later.</div>
	</div>
</div>
<br /><br />
<!-- Ezoic - main_mid_content - mid_content -->
<div id="ezoic-pub-ad-placeholder-104"> </div>
<!-- End Ezoic - main_mid_content - mid_content -->
<div class="breaker"></div>
<div id="expl"><h2 style="padding-top: 3%; font-size:40px;">Why this site?<br /></h2>
<div id="expllong"><p>Calculating the right amounts of money and the transactions (who pays to whom how much) to clear a group's shared costs
and to settle debts for payback can be tedious task - often only solved with the help of spreadsheets.
It even becomes more complicated when one or more community spendings are not shared by the whole group (e.g. one friend
did not want to join the group for the museum trip paid by another friend for everyone).
<br / ><br/>
We therefore established EquiPay.com to provide people with an easy, free, fast and
realiable way to split up their group expenses after holidays, partys, shared presents, festivals, vactions, trips, weddings, roadtrips
or in clubs and shared apartments and so much more.
<br /><br />
Everything happens in the browser without the need of installation of an App on mobile phones.
It is our mission to save groups in which everyone paid some bills from arguments and wasting time after the fun is over.</p>
</div>
<br /><br />
<!-- Ezoic - main_bottom_of_page - bottom_of_page -->
<div id="ezoic-pub-ad-placeholder-111"> </div>
<div class="content">
<!-- logged in user information -->
</div>
<!-- End Ezoic - main_bottom_of_page - bottom_of_page -->
<br />
<a href="#top"><div id="bottomcall">Click to start!</div></a>

<?php  if (isset($_SESSION['username'])) : ?>
	<h5> <a href="front.php?logout='1'" style="color: red;">Logout</a> </h5>
<?php endif ?>

</div>

<footer class="footer mt-auto py-3 bg-dark">
    <div class="container1">
      <span class="text-muted" style="padding-left: 80%;">CopyRight &copy; 2023</span>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script src="https://billzer.com/js/jquery-ui-1.10.3.custom.min.js"></script>
<script src="https://billzer.com/js/jquery.ui.touch-punch.min.js"></script>
<script src="https://billzer.com/js/bootstrap.min.js"></script>
<script src="https://billzer.com/js/bootstrap-select.js"></script>
</body>
</html>