<?php include('server.php') ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EquiPay Login Page</title>
    <link rel = "stylesheet" href="Login.css">
    <link rel="shortcut icon" href="https://i.ibb.co/mRsDprM/Logo.png" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'> 
</head>
<body>
    <div class="main">
        <div class="row">
            <div class="col-md-7">
                <h1>EquiPay</h1>
                <h4>Enter your Login Credentials</h4>

                <form action="login.php" method="post">
				<?php include('errors.php'); ?>
                <div class="input-box">
                <i class='bx bxs-user'></i>
                <label for="first">
                    Username : 
                </label>
                <input type="text" id="username" name="username" placeholder="Enter your Username" required>
                </div>

                <div class="input-box">
                <i class='bx bxs-lock'></i>
                <label for="password">
                    Password : 
                </label>
                <input type="password" id="password" name="password" placeholder="Enter your Password" required>
                </div>

                <div class="wrap">
                    <button type="submit" name = "login_user" style="border-radius: 16px; font-size: larger;">
                        Submit
                    </button>
                </div>
                </form>
                <h6>Not Registered?
                <a href="register.php" style = "text-decoration: none;">
                    Create An Account
                </a>
                </h6>
            </div>
            <div class="col-md-5">
                <img src="https://cdni.iconscout.com/illustration/premium/thumb/male-developer-working-on-laptop-4550337-3779145.png?f=webp" style="height: 300px; width: 400px;">
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html> 