<?php include('server.php') ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EquiPay Registration Page</title>
    <link rel = "stylesheet" href="Register.css">
    <link rel="shortcut icon" href="https://i.ibb.co/mRsDprM/Logo.png" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>    
</head>
<body>
    <div class="main">
        <h1>EquiPay</h1>
        <h4>Register Here</h4>

        <form action="register.php" method = "post">
        <?php include('errors.php'); ?>
        <div class="input-box">
            <i class='bx bxs-user'></i>
            <label>
                Username : 
            </label>
            <input type="text" id="username" name="username" placeholder="Enter your Username" value="<?php echo $username; ?>" required>
        </div>
        
        <div class="input-box">
            <i class='bx bxs-envelope'></i>
            <label>
                Email : 
            </label>
            <input type="email" id="email" name="email" placeholder="Enter your Email ID" value="<?php echo $email; ?>" required>
        </div>

        <div class="input-box">
            <i class='bx bxs-lock'></i>
            <label>
                Password : 
            </label>
            <input type="password" id = "password_1" name="password_1" placeholder="Enter your Password" required>
        </div>

        <div class="input-box">
            <i class='bx bxs-lock'></i>
            <label>
                Confirm Password : 
            </label>
            <input type="password" id = "password_2" name="password_2" placeholder="Enter your Password Again" required>
        </div>

        <div class="wrap">
            <button type="submit" name = "reg_user" style="border-radius: 16px; font-size: larger; margin-top: 20px; margin-bottom: 20px;">
                Submit
            </button>
        </div>
        </form>
        <h6>Aldready Have An Account?
        <a href="login.php" style = "text-decoration: none;">
            Login Here
        </a>
        </h6>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>